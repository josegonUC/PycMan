This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-senior/

Super Senior: A Bold, Round & Fun Font
Super Senior bursts onto the scene with a personality as big as its characters! This bold and round font is designed to bring a touch of fun and whimsy to any project.